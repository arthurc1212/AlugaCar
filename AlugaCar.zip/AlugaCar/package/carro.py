class Carro:
    def __init__(self, modelo, ano, preco_dia, dono, disponivel=True):
        self.modelo = modelo
        self.ano = ano
        self.preco_dia = preco_dia
        self.dono = dono
        self.disponivel = disponivel

    def alugar(self):
        if self.disponivel:
            self.disponivel = False
            return True
        return False

    def devolver(self):
        self.disponivel = True

    def to_dict(self):
        return {
            "modelo": self.modelo,
            "ano": self.ano,
            "preco_dia": self.preco_dia,
            "dono": self.dono.nome if hasattr(self.dono, "nome") else self.dono,
            "disponivel": self.disponivel
        }

    def __str__(self):
        status = "Disponível" if self.disponivel else "Alugado"
        return f"{self.modelo} ({self.ano}) - R${self.preco_dia}/dia - {status}"
