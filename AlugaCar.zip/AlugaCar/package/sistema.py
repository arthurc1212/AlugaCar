import json
import os
from package.usuario import Usuario
from package.carro import Carro

class Sistema:

    def __init__(self):
        self.arq_usuarios = "usuarios.json"
        self.arq_carros = "carros.json"
        self.usuarios = []
        self.carros = []
        self.ler_dados()

    def ler_dados(self):
        try:
            with open(self.arq_usuarios, "r", encoding="utf-8") as f:
                dados = f.read().strip()
                if dados:
                    self.usuarios = [Usuario(**u) for u in json.loads(dados)]
                else:
                    self.usuarios = []
        except (FileNotFoundError, json.JSONDecodeError):
            self.usuarios = []
            
        try:
            with open(self.arq_carros, "r", encoding="utf-8") as f:
                dados = f.read().strip()
                if dados:
                    self.carros = [Carro(**c) for c in json.loads(dados)]
                else:
                    self.carros = []
        except (FileNotFoundError, json.JSONDecodeError):
            self.carros = []
            
    def salvar(self):
        with open(self.arq_usuarios, "w", encoding="utf-8") as f:
            json.dump([u.to_dict() for u in self.usuarios], f, indent=4, ensure_ascii=False)
        with open(self.arq_carros, "w", encoding="utf-8") as f:
            json.dump([c.to_dict() for c in self.carros], f, indent=4, ensure_ascii=False)

    # ---------- Usuários ----------
    def cadastrar_usuario(self, nome, email):
        if any(u.email == email for u in self.usuarios):
            print("\n❌ Usuário já cadastrado!")
            return
        self.usuarios.append(Usuario(nome, email))
        self.salvar()
        print(f"\n✅ Usuário {nome} cadastrado com sucesso!")

    # ---------- Carros ----------
    def cadastrar_carro(self, modelo, ano, preco_dia, dono):
        self.carros.append(Carro(modelo, ano, preco_dia, dono))
        self.salvar()
        print(f"\n🚗 Carro {modelo} cadastrado por {dono}!")

    def listar_carros(self):
        if not self.carros:
            print("\nNenhum carro cadastrado.")
            return
        print("\n🚘 Carros disponíveis:")
        for i, c in enumerate(self.carros, 1):
            status = "Disponível" if c.disponivel else "Alugado"
            print(f"{i}. {c.modelo} - {status} - Dono: {c.dono}")

    def alugar_carro(self, indice):
        try:
            carro = self.carros[indice - 1]
            if carro.alugar():
                self.salvar()
                print(f"\n✅ Você alugou o carro {carro.modelo}!")
            else:
                print("\n❌ Esse carro já está alugado.")
        except IndexError:
            print("\n❌ Índice inválido.")

    def devolver_carro(self, indice):
        try:
            carro = self.carros[indice - 1]
            carro.devolver()
            self.salvar()
            print(f"\n🔁 O carro {carro.modelo} foi devolvido com sucesso!")
        except IndexError:
            print("\n❌ Índice inválido.")

